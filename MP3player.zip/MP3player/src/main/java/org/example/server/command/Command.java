package org.example.server.command;


public interface Command {
    void execute();
}
